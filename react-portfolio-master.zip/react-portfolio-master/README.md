# React Portfolio App

Build a Responsive React Portfolio Website | Tailwind, Framer-Motion, & React Hook Form

Video: https://www.youtube.com/watch?v=JSJ8ftr92Vw

For all related questions and discussions about this project, check out the discord: https://discord.gg/2FfPeEk2mX
